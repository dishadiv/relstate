import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from src.models.real_estate import db, User, Owner, Building, Unit, Tenant, Contract, Payment, Revenue, Expense
from src.routes.auth import auth_bp
from src.routes.users import users_bp
from src.routes.buildings import buildings_bp
from datetime import datetime, date

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['JWT_SECRET_KEY'] = 'jwt-secret-string-change-in-production'

# Enable CORS for all routes
CORS(app, origins="*")

# Initialize JWT
jwt = JWTManager(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(users_bp, url_prefix='/api')
app.register_blueprint(buildings_bp, url_prefix='/api')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def init_sample_data():
    """إنشاء البيانات التجريبية"""
    # التحقق من وجود البيانات مسبقاً
    if User.query.first():
        return
    
    # إنشاء مستخدم إداري افتراضي
    admin_user = User(
        username='admin',
        email='admin@realestate.com',
        full_name='مدير النظام',
        role='admin',
        is_active=True
    )
    admin_user.set_password('admin123')
    db.session.add(admin_user)
    
    # إنشاء مستخدم مدير
    manager_user = User(
        username='manager',
        email='manager@realestate.com',
        full_name='مدير العمليات',
        role='manager',
        is_active=True
    )
    manager_user.set_password('manager123')
    db.session.add(manager_user)
    
    # إنشاء مستخدم عادي
    user = User(
        username='user',
        email='user@realestate.com',
        full_name='موظف النظام',
        role='user',
        is_active=True
    )
    user.set_password('user123')
    db.session.add(user)
    
    db.session.flush()
    
    # إنشاء مالك تجريبي
    owner = Owner(
        owner_name='ورثة احمد محمد بن عبدالعزيز القرين',
        phone='0501234567',
        email='owner@example.com',
        commission_percentage=10.0
    )
    db.session.add(owner)
    db.session.flush()
    
    # إنشاء عقار تجريبي
    building = Building(
        building_number='130',
        address='شارع بندر ت7',
        owner_id=owner.owner_id,
        total_units=9,
        building_type='mixed'
    )
    db.session.add(building)
    db.session.flush()
    
    # إنشاء وحدات تجريبية
    units_data = [
        {'unit_number': '001', 'unit_type': 'shop', 'status': 'rented'},
        {'unit_number': '002', 'unit_type': 'shop', 'status': 'rented'},
        {'unit_number': '003', 'unit_type': 'shop', 'status': 'rented'},
        {'unit_number': '004', 'unit_type': 'shop', 'status': 'rented'},
        {'unit_number': '005', 'unit_type': 'shop', 'status': 'rented'},
        {'unit_number': '01', 'unit_type': 'apartment', 'status': 'rented'},
        {'unit_number': '02', 'unit_type': 'apartment', 'status': 'rented'},
        {'unit_number': '03', 'unit_type': 'apartment', 'status': 'rented'},
        {'unit_number': '04', 'unit_type': 'apartment', 'status': 'rented'},
    ]
    
    units = []
    for unit_data in units_data:
        unit = Unit(
            building_id=building.building_id,
            unit_number=unit_data['unit_number'],
            unit_type=unit_data['unit_type'],
            status=unit_data['status']
        )
        db.session.add(unit)
        units.append(unit)
    
    db.session.flush()
    
    # إنشاء مستأجرين تجريبيين
    tenants_data = [
        {'tenant_name': 'مؤسسة هيا ناصر القحطاني للعبايات', 'tenant_type': 'company', 'mobile_phone': '0565524360'},
        {'tenant_name': 'مؤسسة امبراطور المنجو لتقديم الوجبات', 'tenant_type': 'company', 'mobile_phone': '0507161002'},
        {'tenant_name': 'شركة مجوهرات خالد العمودي', 'tenant_type': 'company', 'mobile_phone': '0505849398'},
        {'tenant_name': 'شركة كنوز بلادي التجارية', 'tenant_type': 'company', 'mobile_phone': '0559443266'},
        {'tenant_name': 'مؤسسة احمد بن حسين الأربش للذهب', 'tenant_type': 'company', 'mobile_phone': '0504830834'},
        {'tenant_name': 'ASTADAN TABANGAY', 'tenant_type': 'individual', 'mobile_phone': '0533961289'},
        {'tenant_name': 'منصور نانغارات', 'tenant_type': 'individual', 'mobile_phone': '0590184783'},
        {'tenant_name': 'شركة نجمة مضيئة للدعاية والاعلان', 'tenant_type': 'company', 'mobile_phone': '0508831931'},
        {'tenant_name': 'وقاص علي عبد الستار', 'tenant_type': 'individual', 'mobile_phone': '0572688146'},
    ]
    
    tenants = []
    for tenant_data in tenants_data:
        tenant = Tenant(
            tenant_name=tenant_data['tenant_name'],
            tenant_type=tenant_data['tenant_type'],
            mobile_phone=tenant_data['mobile_phone']
        )
        db.session.add(tenant)
        tenants.append(tenant)
    
    db.session.flush()
    
    # إنشاء عقود تجريبية
    contracts_data = [
        {'contract_number': '2109', 'unit_idx': 0, 'tenant_idx': 0, 'start_date': '2022-01-18', 'end_date': '2026-01-17', 'annual_rent': 40000, 'monthly_rent': 3333.33, 'installments': 4, 'paid_until': '2025-04-18'},
        {'contract_number': '2185', 'unit_idx': 1, 'tenant_idx': 1, 'start_date': '2022-08-01', 'end_date': '2025-07-31', 'annual_rent': 40000, 'monthly_rent': 3333.33, 'installments': 4, 'paid_until': '2024-11-01'},
        {'contract_number': '1912', 'unit_idx': 2, 'tenant_idx': 2, 'start_date': '2021-02-12', 'end_date': '2025-08-11', 'annual_rent': 110000, 'monthly_rent': 9166.67, 'installments': 2, 'paid_until': '2025-08-12'},
        {'contract_number': '2063', 'unit_idx': 3, 'tenant_idx': 3, 'start_date': '2021-11-16', 'end_date': '2025-12-31', 'annual_rent': 80000, 'monthly_rent': 6666.67, 'installments': 2, 'paid_until': '2025-07-01'},
        {'contract_number': '2188', 'unit_idx': 4, 'tenant_idx': 4, 'start_date': '2022-09-01', 'end_date': '2026-02-28', 'annual_rent': 70000, 'monthly_rent': 5833.33, 'installments': 2, 'paid_until': '2025-09-01'},
    ]
    
    for contract_data in contracts_data:
        contract = Contract(
            contract_number=contract_data['contract_number'],
            unit_id=units[contract_data['unit_idx']].unit_id,
            tenant_id=tenants[contract_data['tenant_idx']].tenant_id,
            start_date=datetime.strptime(contract_data['start_date'], '%Y-%m-%d').date(),
            end_date=datetime.strptime(contract_data['end_date'], '%Y-%m-%d').date(),
            duration_months=12,
            annual_rent=contract_data['annual_rent'],
            monthly_rent=contract_data['monthly_rent'],
            payment_installments=contract_data['installments'],
            installment_amount=contract_data['annual_rent'] / contract_data['installments'],
            paid_until_date=datetime.strptime(contract_data['paid_until'], '%Y-%m-%d').date(),
            contract_status='active'
        )
        db.session.add(contract)
    
    # إضافة إيرادات تجريبية
    revenues_data = [
        {'building_id': building.building_id, 'revenue_type': 'rent', 'amount': 10000, 'payment_date': '2025-06-15', 'description': 'إيجار الربع الثاني - عقد 2109'},
        {'building_id': building.building_id, 'revenue_type': 'rent', 'amount': 55000, 'payment_date': '2025-06-12', 'description': 'إيجار نصف سنوي - عقد 1912'},
        {'building_id': building.building_id, 'revenue_type': 'deposit', 'amount': 5000, 'payment_date': '2025-06-13', 'description': 'تأمين وحدة جديدة'},
    ]
    
    for revenue_data in revenues_data:
        revenue = Revenue(
            building_id=revenue_data['building_id'],
            revenue_type=revenue_data['revenue_type'],
            amount=revenue_data['amount'],
            payment_date=datetime.strptime(revenue_data['payment_date'], '%Y-%m-%d').date(),
            description=revenue_data['description'],
            created_by=admin_user.user_id
        )
        db.session.add(revenue)
    
    # إضافة مصروفات تجريبية
    expenses_data = [
        {'building_id': building.building_id, 'expense_type': 'maintenance', 'amount': 2500, 'expense_date': '2025-06-16', 'description': 'صيانة المصعد - عمارة 130', 'vendor_name': 'شركة الصيانة المتقدمة'},
        {'building_id': building.building_id, 'expense_type': 'utilities', 'amount': 1800, 'expense_date': '2025-06-15', 'description': 'فاتورة الكهرباء - عمارة 130', 'vendor_name': 'شركة الكهرباء السعودية'},
        {'building_id': building.building_id, 'expense_type': 'maintenance', 'amount': 1200, 'expense_date': '2025-06-13', 'description': 'أعمال دهان - وحدة 130/005', 'vendor_name': 'مؤسسة الدهانات الحديثة'},
    ]
    
    for expense_data in expenses_data:
        expense = Expense(
            building_id=expense_data['building_id'],
            expense_type=expense_data['expense_type'],
            amount=expense_data['amount'],
            expense_date=datetime.strptime(expense_data['expense_date'], '%Y-%m-%d').date(),
            description=expense_data['description'],
            vendor_name=expense_data['vendor_name'],
            created_by=admin_user.user_id
        )
        db.session.add(expense)
    
    db.session.commit()

with app.app_context():
    db.create_all()
    init_sample_data()

@app.route('/api/dashboard/summary', methods=['GET'])
def dashboard_summary():
    """ملخص لوحة التحكم"""
    try:
        from sqlalchemy import func
        
        # حساب الإحصائيات الأساسية
        total_buildings = Building.query.count()
        total_units = Unit.query.count()
        rented_units = Unit.query.filter_by(status='rented').count()
        vacant_units = Unit.query.filter_by(status='available').count()
        active_contracts = Contract.query.filter_by(contract_status='active').count()
        
        # حساب الملخص المالي للشهر الحالي
        today = date.today()
        start_of_month = today.replace(day=1)
        
        monthly_revenues = db.session.query(func.sum(Revenue.amount)).filter(
            Revenue.payment_date >= start_of_month,
            Revenue.payment_date <= today
        ).scalar() or 0
        
        monthly_expenses = db.session.query(func.sum(Expense.amount)).filter(
            Expense.expense_date >= start_of_month,
            Expense.expense_date <= today
        ).scalar() or 0
        
        net_income = float(monthly_revenues) - float(monthly_expenses)
        commission_amount = net_income * 0.1  # 10% عمولة
        owner_share = net_income - commission_amount
        
        # حساب العقود المتأخرة
        overdue_contracts = Contract.query.filter(
            Contract.paid_until_date < today,
            Contract.contract_status == 'active'
        ).count()
        
        # حساب العقود المنتهية قريباً (خلال 30 يوم)
        from datetime import timedelta
        expiring_date = today + timedelta(days=30)
        expiring_contracts = Contract.query.filter(
            Contract.end_date <= expiring_date,
            Contract.contract_status == 'active'
        ).count()
        
        return jsonify({
            'success': True,
            'data': {
                'total_buildings': total_buildings,
                'total_units': total_units,
                'rented_units': rented_units,
                'vacant_units': vacant_units,
                'active_contracts': active_contracts,
                'monthly_revenues': float(monthly_revenues),
                'monthly_expenses': float(monthly_expenses),
                'net_income': float(net_income),
                'commission_amount': float(commission_amount),
                'owner_share': float(owner_share),
                'overdue_contracts': overdue_contracts,
                'expiring_contracts': expiring_contracts,
                'occupancy_rate': round((rented_units / total_units * 100) if total_units > 0 else 0, 1)
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

