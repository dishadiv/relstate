from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.real_estate import db, User
from functools import wraps

users_bp = Blueprint('users', __name__)

def admin_required(f):
    """ديكوريتر للتحقق من صلاحيات الإدارة"""
    @wraps(f)
    @jwt_required()
    def decorated_function(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role != 'admin':
            return jsonify({
                'success': False,
                'error': 'غير مصرح لك بالوصول لهذه الصفحة'
            }), 403
        
        return f(*args, **kwargs)
    return decorated_function

def manager_required(f):
    """ديكوريتر للتحقق من صلاحيات المدير أو الإدارة"""
    @wraps(f)
    @jwt_required()
    def decorated_function(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role not in ['admin', 'manager']:
            return jsonify({
                'success': False,
                'error': 'غير مصرح لك بالوصول لهذه الصفحة'
            }), 403
        
        return f(*args, **kwargs)
    return decorated_function

@users_bp.route('/users', methods=['GET'])
@manager_required
def get_users():
    """الحصول على قائمة المستخدمين"""
    try:
        users = User.query.all()
        return jsonify({
            'success': True,
            'data': [user.to_dict() for user in users]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@users_bp.route('/users', methods=['POST'])
@admin_required
def create_user():
    """إنشاء مستخدم جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['username', 'email', 'password', 'full_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'{field} مطلوب'
                }), 400
        
        # التحقق من عدم وجود المستخدم مسبقاً
        if User.query.filter_by(username=data['username']).first():
            return jsonify({
                'success': False,
                'error': 'اسم المستخدم موجود مسبقاً'
            }), 400
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({
                'success': False,
                'error': 'البريد الإلكتروني موجود مسبقاً'
            }), 400
        
        # إنشاء المستخدم الجديد
        user = User(
            username=data['username'],
            email=data['email'],
            full_name=data['full_name'],
            role=data.get('role', 'user'),
            is_active=data.get('is_active', True)
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@users_bp.route('/users/<int:user_id>', methods=['GET'])
@manager_required
def get_user(user_id):
    """الحصول على بيانات مستخدم محدد"""
    try:
        user = User.query.get_or_404(user_id)
        return jsonify({
            'success': True,
            'data': user.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@users_bp.route('/users/<int:user_id>', methods=['PUT'])
@admin_required
def update_user(user_id):
    """تحديث بيانات مستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        # تحديث البيانات
        if 'username' in data:
            # التحقق من عدم وجود اسم المستخدم مسبقاً
            existing_user = User.query.filter_by(username=data['username']).first()
            if existing_user and existing_user.user_id != user_id:
                return jsonify({
                    'success': False,
                    'error': 'اسم المستخدم موجود مسبقاً'
                }), 400
            user.username = data['username']
        
        if 'email' in data:
            # التحقق من عدم وجود البريد الإلكتروني مسبقاً
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.user_id != user_id:
                return jsonify({
                    'success': False,
                    'error': 'البريد الإلكتروني موجود مسبقاً'
                }), 400
            user.email = data['email']
        
        if 'full_name' in data:
            user.full_name = data['full_name']
        
        if 'role' in data:
            user.role = data['role']
        
        if 'is_active' in data:
            user.is_active = data['is_active']
        
        if 'password' in data and data['password']:
            user.set_password(data['password'])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': user.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@users_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    """حذف مستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        
        # منع حذف المستخدم الحالي
        current_user_id = get_jwt_identity()
        if user_id == current_user_id:
            return jsonify({
                'success': False,
                'error': 'لا يمكن حذف حسابك الخاص'
            }), 400
        
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم حذف المستخدم بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

