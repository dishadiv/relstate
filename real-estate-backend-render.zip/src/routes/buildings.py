from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.real_estate import db, Building, Unit, Owner, Revenue, Expense
from src.routes.users import manager_required
from datetime import datetime
from sqlalchemy import func

buildings_bp = Blueprint('buildings', __name__)

@buildings_bp.route('/buildings', methods=['GET'])
@jwt_required()
def get_buildings():
    """الحصول على قائمة العقارات"""
    try:
        buildings = Building.query.all()
        buildings_data = []
        
        for building in buildings:
            building_dict = building.to_dict()
            
            # حساب الإحصائيات
            total_units = Unit.query.filter_by(building_id=building.building_id).count()
            rented_units = Unit.query.filter_by(building_id=building.building_id, status='rented').count()
            vacant_units = Unit.query.filter_by(building_id=building.building_id, status='available').count()
            
            # حساب الإيرادات الشهرية
            monthly_revenue = db.session.query(func.sum(Revenue.amount)).filter(
                Revenue.building_id == building.building_id,
                func.extract('month', Revenue.payment_date) == datetime.now().month,
                func.extract('year', Revenue.payment_date) == datetime.now().year
            ).scalar() or 0
            
            building_dict.update({
                'total_units': total_units,
                'rented_units': rented_units,
                'vacant_units': vacant_units,
                'monthly_revenue': float(monthly_revenue)
            })
            
            buildings_data.append(building_dict)
        
        return jsonify({
            'success': True,
            'data': buildings_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings', methods=['POST'])
@manager_required
def create_building():
    """إنشاء عقار جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['building_number', 'address', 'owner_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'{field} مطلوب'
                }), 400
        
        # التحقق من وجود المالك
        owner = Owner.query.get(data['owner_id'])
        if not owner:
            return jsonify({
                'success': False,
                'error': 'المالك غير موجود'
            }), 404
        
        building = Building(
            building_number=data['building_number'],
            address=data['address'],
            owner_id=data['owner_id'],
            total_units=data.get('total_units', 0),
            building_type=data.get('building_type', 'mixed'),
            description=data.get('description')
        )
        
        db.session.add(building)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': building.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings/<int:building_id>', methods=['GET'])
@jwt_required()
def get_building(building_id):
    """الحصول على بيانات عقار محدد"""
    try:
        building = Building.query.get_or_404(building_id)
        return jsonify({
            'success': True,
            'data': building.to_dict()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings/<int:building_id>', methods=['PUT'])
@manager_required
def update_building(building_id):
    """تحديث بيانات عقار"""
    try:
        building = Building.query.get_or_404(building_id)
        data = request.get_json()
        
        if 'building_number' in data:
            building.building_number = data['building_number']
        if 'address' in data:
            building.address = data['address']
        if 'owner_id' in data:
            # التحقق من وجود المالك
            owner = Owner.query.get(data['owner_id'])
            if not owner:
                return jsonify({
                    'success': False,
                    'error': 'المالك غير موجود'
                }), 404
            building.owner_id = data['owner_id']
        if 'total_units' in data:
            building.total_units = data['total_units']
        if 'building_type' in data:
            building.building_type = data['building_type']
        if 'description' in data:
            building.description = data['description']
        
        building.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': building.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings/<int:building_id>', methods=['DELETE'])
@manager_required
def delete_building(building_id):
    """حذف عقار"""
    try:
        building = Building.query.get_or_404(building_id)
        db.session.delete(building)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم حذف العقار بنجاح'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings/<int:building_id>/units', methods=['GET'])
@jwt_required()
def get_building_units(building_id):
    """الحصول على وحدات عقار محدد"""
    try:
        units = Unit.query.filter_by(building_id=building_id).all()
        return jsonify({
            'success': True,
            'data': [unit.to_dict() for unit in units]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@buildings_bp.route('/buildings/<int:building_id>/financial-summary', methods=['GET'])
@jwt_required()
def get_building_financial_summary(building_id):
    """الحصول على الملخص المالي لعقار محدد"""
    try:
        building = Building.query.get_or_404(building_id)
        
        # حساب إجمالي الإيرادات
        total_revenues = db.session.query(func.sum(Revenue.amount)).filter(
            Revenue.building_id == building_id
        ).scalar() or 0
        
        # حساب إجمالي المصروفات
        total_expenses = db.session.query(func.sum(Expense.amount)).filter(
            Expense.building_id == building_id
        ).scalar() or 0
        
        # حساب صافي الدخل
        net_income = total_revenues - total_expenses
        
        # حساب العمولة
        commission_percentage = building.owner.commission_percentage if building.owner else 10
        commission_amount = net_income * (commission_percentage / 100)
        owner_share = net_income - commission_amount
        
        return jsonify({
            'success': True,
            'data': {
                'building_id': building_id,
                'building_number': building.building_number,
                'total_revenues': float(total_revenues),
                'total_expenses': float(total_expenses),
                'net_income': float(net_income),
                'commission_percentage': float(commission_percentage),
                'commission_amount': float(commission_amount),
                'owner_share': float(owner_share)
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

