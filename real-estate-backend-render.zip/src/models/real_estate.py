from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
from passlib.hash import pbkdf2_sha256 as pwd_context

db = SQLAlchemy()

# جدول المستخدمين
class User(db.Model):
    __tablename__ = 'users'
    
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), default='user')  # admin, manager, user
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """تشفير كلمة المرور"""
        self.password_hash = pwd_context.hash(password)
    
    def check_password(self, password):
        """التحقق من كلمة المرور"""
        return pwd_context.verify(password, self.password_hash)
    
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'role': self.role,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول الملاك
class Owner(db.Model):
    __tablename__ = 'owners'
    
    owner_id = db.Column(db.Integer, primary_key=True)
    owner_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    email = db.Column(db.String(100))
    national_id = db.Column(db.String(20))
    address = db.Column(db.Text)
    commission_percentage = db.Column(db.Float, default=10.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    buildings = db.relationship('Building', backref='owner', lazy=True)
    
    def to_dict(self):
        return {
            'owner_id': self.owner_id,
            'owner_name': self.owner_name,
            'phone': self.phone,
            'email': self.email,
            'national_id': self.national_id,
            'address': self.address,
            'commission_percentage': float(self.commission_percentage) if self.commission_percentage else 0.0,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول العقارات
class Building(db.Model):
    __tablename__ = 'buildings'
    
    building_id = db.Column(db.Integer, primary_key=True)
    building_number = db.Column(db.String(50), nullable=False)
    address = db.Column(db.Text, nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('owners.owner_id'), nullable=False)
    total_units = db.Column(db.Integer, default=0)
    building_type = db.Column(db.String(20), default='mixed')  # residential, commercial, mixed
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    units = db.relationship('Unit', backref='building', lazy=True, cascade='all, delete-orphan')
    revenues = db.relationship('Revenue', backref='building', lazy=True)
    expenses = db.relationship('Expense', backref='building', lazy=True)
    
    def to_dict(self):
        return {
            'building_id': self.building_id,
            'building_number': self.building_number,
            'address': self.address,
            'owner_id': self.owner_id,
            'owner_name': self.owner.owner_name if self.owner else None,
            'total_units': self.total_units,
            'building_type': self.building_type,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول الوحدات
class Unit(db.Model):
    __tablename__ = 'units'
    
    unit_id = db.Column(db.Integer, primary_key=True)
    building_id = db.Column(db.Integer, db.ForeignKey('buildings.building_id'), nullable=False)
    unit_number = db.Column(db.String(20), nullable=False)
    unit_type = db.Column(db.String(20), default='apartment')  # apartment, shop, office
    status = db.Column(db.String(20), default='available')  # available, rented, maintenance
    area = db.Column(db.Float)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    contracts = db.relationship('Contract', backref='unit', lazy=True)
    
    def to_dict(self):
        return {
            'unit_id': self.unit_id,
            'building_id': self.building_id,
            'building_number': self.building.building_number if self.building else None,
            'unit_number': self.unit_number,
            'unit_type': self.unit_type,
            'status': self.status,
            'area': float(self.area) if self.area else None,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول المستأجرين
class Tenant(db.Model):
    __tablename__ = 'tenants'
    
    tenant_id = db.Column(db.Integer, primary_key=True)
    tenant_name = db.Column(db.String(100), nullable=False)
    tenant_type = db.Column(db.String(20), default='individual')  # individual, company
    mobile_phone = db.Column(db.String(20))
    work_phone = db.Column(db.String(20))
    email = db.Column(db.String(100))
    national_id = db.Column(db.String(20))
    commercial_register = db.Column(db.String(50))
    address = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    contracts = db.relationship('Contract', backref='tenant', lazy=True)
    
    def to_dict(self):
        return {
            'tenant_id': self.tenant_id,
            'tenant_name': self.tenant_name,
            'tenant_type': self.tenant_type,
            'mobile_phone': self.mobile_phone,
            'work_phone': self.work_phone,
            'email': self.email,
            'national_id': self.national_id,
            'commercial_register': self.commercial_register,
            'address': self.address,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول العقود
class Contract(db.Model):
    __tablename__ = 'contracts'
    
    contract_id = db.Column(db.Integer, primary_key=True)
    contract_number = db.Column(db.String(50), unique=True, nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.unit_id'), nullable=False)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.tenant_id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    duration_months = db.Column(db.Integer, nullable=False)
    annual_rent = db.Column(db.Numeric(10, 2), nullable=False)
    monthly_rent = db.Column(db.Numeric(10, 2), nullable=False)
    payment_installments = db.Column(db.Integer, default=4)  # عدد الدفعات في السنة
    installment_amount = db.Column(db.Numeric(10, 2))
    paid_until_date = db.Column(db.Date)
    contract_status = db.Column(db.String(20), default='active')  # active, expired, terminated
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # العلاقات
    payments = db.relationship('Payment', backref='contract', lazy=True)
    
    def to_dict(self):
        return {
            'contract_id': self.contract_id,
            'contract_number': self.contract_number,
            'unit_id': self.unit_id,
            'unit_number': self.unit.unit_number if self.unit else None,
            'building_number': self.unit.building.building_number if self.unit and self.unit.building else None,
            'tenant_id': self.tenant_id,
            'tenant_name': self.tenant.tenant_name if self.tenant else None,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'duration_months': self.duration_months,
            'annual_rent': float(self.annual_rent) if self.annual_rent else 0.0,
            'monthly_rent': float(self.monthly_rent) if self.monthly_rent else 0.0,
            'payment_installments': self.payment_installments,
            'installment_amount': float(self.installment_amount) if self.installment_amount else 0.0,
            'paid_until_date': self.paid_until_date.isoformat() if self.paid_until_date else None,
            'contract_status': self.contract_status,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# جدول المدفوعات (سندات القبض)
class Payment(db.Model):
    __tablename__ = 'payments'
    
    payment_id = db.Column(db.Integer, primary_key=True)
    contract_id = db.Column(db.Integer, db.ForeignKey('contracts.contract_id'), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    payment_method = db.Column(db.String(20), default='cash')  # cash, bank_transfer, check
    receipt_number = db.Column(db.String(50))
    notes = db.Column(db.Text)
    created_by = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'payment_id': self.payment_id,
            'contract_id': self.contract_id,
            'contract_number': self.contract.contract_number if self.contract else None,
            'tenant_name': self.contract.tenant.tenant_name if self.contract and self.contract.tenant else None,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None,
            'amount': float(self.amount) if self.amount else 0.0,
            'payment_method': self.payment_method,
            'receipt_number': self.receipt_number,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# جدول الإيرادات
class Revenue(db.Model):
    __tablename__ = 'revenues'
    
    revenue_id = db.Column(db.Integer, primary_key=True)
    building_id = db.Column(db.Integer, db.ForeignKey('buildings.building_id'), nullable=False)
    revenue_type = db.Column(db.String(20), nullable=False)  # rent, deposit, other
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    description = db.Column(db.Text)
    reference_number = db.Column(db.String(50))
    created_by = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'revenue_id': self.revenue_id,
            'building_id': self.building_id,
            'building_number': self.building.building_number if self.building else None,
            'revenue_type': self.revenue_type,
            'amount': float(self.amount) if self.amount else 0.0,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None,
            'description': self.description,
            'reference_number': self.reference_number,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# جدول المصروفات
class Expense(db.Model):
    __tablename__ = 'expenses'
    
    expense_id = db.Column(db.Integer, primary_key=True)
    building_id = db.Column(db.Integer, db.ForeignKey('buildings.building_id'), nullable=False)
    expense_type = db.Column(db.String(20), nullable=False)  # maintenance, utilities, other
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    expense_date = db.Column(db.Date, nullable=False)
    description = db.Column(db.Text)
    vendor_name = db.Column(db.String(100))
    receipt_number = db.Column(db.String(50))
    created_by = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'expense_id': self.expense_id,
            'building_id': self.building_id,
            'building_number': self.building.building_number if self.building else None,
            'expense_type': self.expense_type,
            'amount': float(self.amount) if self.amount else 0.0,
            'expense_date': self.expense_date.isoformat() if self.expense_date else None,
            'description': self.description,
            'vendor_name': self.vendor_name,
            'receipt_number': self.receipt_number,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

